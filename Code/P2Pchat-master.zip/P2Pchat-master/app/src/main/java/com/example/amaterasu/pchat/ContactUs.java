package com.example.amaterasu.pchat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by yogesh on 3/3/16.
 */
public class ContactUs extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_us);
    }
}
