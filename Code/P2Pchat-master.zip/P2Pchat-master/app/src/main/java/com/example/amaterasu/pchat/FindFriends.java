package com.example.amaterasu.pchat;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by dell on 29/2/16.
 */
public class FindFriends extends AppCompatActivity {



}
