package com.example.amaterasu.pchat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by dell on 29/2/16.
 */
public class ChangeName extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_name);
    }
}
