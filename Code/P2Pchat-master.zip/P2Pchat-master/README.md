# P2Pchat
* This is the beta version of the peer to peer android chat application.
* Basic architecture involves a discovery server and peers to connect.

##Limitations
* peers should be connected to wifi and not mobiles data net.
* crashes without mobile being connected to wifi

##Future work 
* Proper structing of code.
* Adding service of mobile's data net.
* Modification to UI

##How to start with it.
* There is php script running on athena.nitc.ac.in (in case, scripts are required, contact: shailendra.sh@zoho.com)
* Install the app on peers to connect, find your buddies in the online tab, start chatting.
